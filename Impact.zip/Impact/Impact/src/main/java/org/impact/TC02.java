package org.impact;

import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TC02 extends Functionlibrary {

	Objectrepository p = new Objectrepository();

	@BeforeClass
	public static void browserStart() {

		browserInvoke("https://member-stage6.impactradius.net/login.user");
	}

	@Before
	public void exeStartTime() {

		Date d = new Date();
		System.out.println("Execution Start Time: " + d);
	}

	@Test
	public void executeTest() throws Exception {
		System.out.println("TC02 - Validate DASHBOARD tab - Show and Hide Compare");
		sendData(p.getLoginId(), "qaadvertiser1");
		sendData(p.getPassword(), "5umbrella9");
		click(p.getSignin());
		click(p.getDropDown());
		click(p.getDashboard());
		click(p.getLast7Days());
		click(p.getShowCompare());
		click(p.getDateRange());
		click(p.getPreviousPeriod());
		click(p.getPreviousMonth());
		click(p.getPreviousYear());
		Assert.assertTrue(p.getPreviousPeriod().getText().contains(String.valueOf("Previous Period")));
		Assert.assertTrue(p.getPreviousMonth().getText().contains(String.valueOf("Previous Month")));
		Assert.assertTrue(p.getPreviousYear().getText().contains(String.valueOf("Previous Year")));
		click(p.getHideCompare());
		Assert.assertTrue(p.getShowCompare().isEnabled() == false);
	}

	@After
	public void exeEndTime() {
		Date d = new Date();
		System.out.println("Execution End Time: " + d);

	}

	@AfterClass
	public static void browserClose() {
		tearDown();

	}

}
