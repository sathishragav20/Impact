package org.impact;

import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TC01 extends Functionlibrary {

	Objectrepository p = new Objectrepository();

	@BeforeClass
	public static void browserStart() {

		browserInvoke("https://member-stage6.impactradius.net/login.user");
	}

	@Before
	public void exeStartTime() {

		Date d = new Date();
		System.out.println("Execution Start Time: " + d);
	}

	@Test
	public void executeTest() throws Exception {
		System.out.println("TC01 - Validate DASHBOARD tab - Date Range");
		sendData(p.getLoginId(), "qaadvertiser1");
		sendData(p.getPassword(), "5umbrella9");
		click(p.getSignin());
		click(p.getDashboard());
		click(p.getDropDown());
		click(p.getLast7Days());
		click(p.getWeektoDateSun());
		click(p.getWeektoDateMon());
		click(p.getLast30Days());
		click(p.getMonthtoDate());
		Assert.assertTrue(p.getLast7Days().getText().contains(String.valueOf("Last 7 days")));
		Assert.assertTrue(p.getWeektoDateSun().getText().contains(String.valueOf("Week to Date (Sun - Today)")));
		Assert.assertTrue(p.getWeektoDateMon().getText().contains(String.valueOf("Week to Date (Mon - Today)")));
		Assert.assertTrue(p.getLast30Days().getText().contains(String.valueOf("Last 30 days")));
		Assert.assertTrue(p.getMonthtoDate().getText().contains(String.valueOf("Month to Date")));

	}

	@After
	public void exeEndTime() {
		Date d = new Date();
		System.out.println("Execution End Time: " + d);

	}

	@AfterClass
	public static void browserClose() {
		tearDown();

	}

}
