package org.impact;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Functionlibrary {

	public static WebDriver driver;
	public static String driverPath = "D:\\Eclipse Workspaces\\My Workspace\\Framework\\driver\\chromedriver.exe";
	public static Select s = null;

	public static WebDriver browserInvoke(String url) {
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		return driver;
	}

	public static void click(WebElement element) {
		element.click();
	}

	public static void sendData(WebElement element, String data) {
		element.sendKeys(data);
	}

	public static void selectByText(WebElement element, String name) {
		s = new Select(element);
		s.selectByVisibleText(name);
	}

	public static void tearDown() {
		driver.close();
	}
}
