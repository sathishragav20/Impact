package org.impact;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Objectrepository extends Functionlibrary {

	public Objectrepository() {
		PageFactory.initElements(driver, this);
	}

	// Login

	@FindBy(id = "j_username")
	public WebElement loginId;
	@FindBy(id = "j_password")
	public WebElement password;
	@FindBy(id = "loginButton")
	public WebElement signin;

	public WebElement getLoginId() {
		return loginId;
	}

	public WebElement getPassword() {
		return password;
	}

	public WebElement getSignin() {
		return signin;
	}

	// Dashboard

	@FindBy(xpath = "//span[text()='Last 7 days']")
	public WebElement last7Days;

	@FindBy(id = "menuitem-1026")
	public WebElement weektoDateSun;

	@FindBy(id = "menuitem-1027")
	public WebElement weektoDateMon;

	@FindBy(id = "menuitem-1028")
	public WebElement last30Days;

	@FindBy(id = "menuitem-1029")
	public WebElement monthtoDate;

	@FindBy(id = "splitbutton-1030-btnInnerEl")
	public WebElement dropDown;

	@FindBy(xpath = "//span[text()='Show compare']")
	public WebElement showcompare;

	@FindBy(xpath = "//span[text()='Select range']")
	public WebElement selectdaterange;

	@FindBy(xpath = "//span[text()='Previous Period']")
	public WebElement previousperiod;

	@FindBy(xpath = "//span[text()='Previous Month']")
	public WebElement previousmonth;

	@FindBy(xpath = "//span[text()='Previous Year']")
	public WebElement previousyear;

	@FindBy(xpath = "//span[text()='Hide compare']")
	public WebElement hidecompare;

	@FindBy(id = "dashSettings")
	public WebElement pencilicon;

	@FindBy(id = "uitk_ext_1480")
	public WebElement disbyPartner;

	@FindBy(id = "uitk_ext_1521")
	public WebElement perfbyad;

	@FindBy(xpath = "//span[text()='Apply']")
	public WebElement apply;

	@FindBy(xpath = "//span[contains(text(),'Distribution by')]")
	public WebElement disbypartnerReport;

	@FindBy(xpath = "//a[text()='View Report']")
	public WebElement viewReport;

	@FindBy(xpath = "//div[starts-with(text(),'Performance by')]")
	public WebElement perfbyAdreport;

	@FindBy(id = "ads_radius_header_hd-textEl")
	public WebElement perbyad;

	@FindBy(xpath = "//div[text()='Dashboard']")
	public WebElement dashboard;

	public WebElement getperfbyad() {
		return perbyad;
	}

	public WebElement getDashboard() {
		return dashboard;
	}

	public WebElement getDisPartnerReport() {
		return disbypartnerReport;
	}

	public WebElement getPerfByAdReport() {
		return perfbyAdreport;
	}

	public WebElement getApply() {
		return apply;
	}

	public WebElement getViewReport() {
		return viewReport;
	}

	public WebElement getPerfByAd() {
		return perfbyad;
	}

	public WebElement getDisByPartner() {
		return disbyPartner;
	}

	public WebElement getPencilIcon() {
		return pencilicon;
	}

	public WebElement getPreviousPeriod() {
		return previousperiod;
	}

	public WebElement getPreviousMonth() {
		return previousmonth;
	}

	public WebElement getPreviousYear() {
		return previousyear;
	}

	public WebElement getDateRange() {
		return selectdaterange;
	}

	public WebElement getShowCompare() {
		return showcompare;
	}

	public WebElement getHideCompare() {
		return hidecompare;
	}

	public WebElement getLast7Days() {
		return last7Days;
	}

	public WebElement getWeektoDateSun() {
		return weektoDateSun;
	}

	public WebElement getWeektoDateMon() {
		return weektoDateMon;
	}

	public WebElement getLast30Days() {
		return last30Days;
	}

	public WebElement getMonthtoDate() {
		return monthtoDate;
	}

	public WebElement getDropDown() {
		return dropDown;
	}

}