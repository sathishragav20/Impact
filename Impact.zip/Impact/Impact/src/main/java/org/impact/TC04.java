package org.impact;

import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TC04 extends Functionlibrary {

	Objectrepository p = new Objectrepository();

	@BeforeClass
	public static void browserStart() {

		browserInvoke("https://member-stage6.impactradius.net/login.user");
	}

	@Before
	public void exeStartTime() {

		Date d = new Date();
		System.out.println("Execution Start Time: " + d);
	}

	@Test
	public void executeTest() throws Exception {
		System.out.println("TC04 - Validate DASHBOARD tab -  Performance by Ad Widget");
		sendData(p.getLoginId(), "qaadvertiser1");
		sendData(p.getPassword(), "5umbrella9");
		click(p.getSignin());
		click(p.getDashboard());
		click(p.getDropDown());
		click(p.getMonthtoDate());
		click(p.getPencilIcon());
		click(p.getPerfByAd());
		click(p.getApply());
		click(p.getViewReport());
		Assert.assertTrue(p.getPerfByAdReport().getText().contains(String.valueOf("Performance by Ad")));
	}

	@After
	public void exeEndTime() {
		Date d = new Date();
		System.out.println("Execution End Time: " + d);

	}

	@AfterClass
	public static void browserClose() {
		tearDown();

	}

}
